# Import the MySQL connector library
import mysql.connector

# Main program execution starts here
if __name__ == '__main__':
    # Connect to the MySQL database using provided credentials and port
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="f1_data",
        port='3307',
    )

    # Create a cursor object to interact with the database
    cursor = mydb.cursor()

    # Execute the SQL query to retrieve summarized data per nationality
    cursor.execute("""
        SELECT 
            Nationality,                            -- Driver's nationality
            AVG(PTS) AS 'avg_pts',                  -- Average points of drivers from this nationality
            
            -- Subquery to get the minimum lap time for each nationality
            (SELECT MIN(Time) 
             FROM fastest_laps, drivers AS d2 
             WHERE fastest_laps.Driver = d2.Driver 
               AND d2.Nationality = d1.Nationality) AS min_time,

            -- Subquery to get the latest win date for each nationality
            (SELECT MAX(Date) 
             FROM winners, drivers AS d3 
             WHERE winners.Winner = d3.Driver 
               AND d3.Nationality = d1.Nationality) AS latest

        FROM drivers AS d1                         -- Main query on the drivers table
        GROUP BY Nationality                       -- Group results by nationality

        -- Only include nationalities that have at least one lap time and one win date
        HAVING min_time IS NOT NULL AND latest IS NOT NULL
    """)

    # Fetch all the results and print them in a single line, comma-separated
    print(', '.join(str(row) for row in cursor.fetchall()))
